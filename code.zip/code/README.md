# 《从零开始学习Agent》配套代码

本书所有代码均在本目录下，按章节组织。每章代码可独立运行。

## 环境准备

```bash
pip install -r requirements.txt

# 复制并配置环境变量
cp .env.example .env
# 编辑 .env，填入你的 API Key
```

## 各章代码

| 章节 | 目录 | 说明 | 运行方式 |
|------|------|------|---------|
| 第1章 | `chapter01_simple_agent/` | 最简对话 Agent | `python chapter01_simple_agent/simple_agent.py` |
| 第2章 | `chapter02_eliza/` | ELIZA 聊天机器人 | `python chapter02_eliza/eliza.py` |
| 第3章 | `chapter03_llm_basics/` | N-gram、词嵌入、BPE | `python chapter03_llm_basics/ngram.py` 等 |
| 第4章 | `chapter04_tool_system/` | 工具系统 + 旅行助手 | `python chapter04_tool_system/travel_agent.py` |
| 第5章 | `chapter05_paradigms/` | ReAct / Plan-Solve / Reflection | `python chapter05_paradigms/react_agent.py` |
| 第6章 | `chapter06_framework/` | HelloAgents 轻量框架 | `python chapter06_framework/hello_agents/agents/simple_agent.py` |
| 第9章 | `chapter09_multi_agent/` | AutoGen 多 Agent 协作 | `python chapter09_multi_agent/autogen_backlog.py` |
| 第10章 | `chapter10_evaluation/` | 评估与 Benchmark | `python chapter10_evaluation/benchmark.py` |

## 依赖说明

- **第1-5章** 需要 `openai` + `python-dotenv`
- **第4章** 额外需要 `requests`
- **第2-3章、第10章** 仅需 Python 标准库
- **第9章** 需要 `autogen-agentchat` + `autogen-ext[openai]`

## 注意事项

- 第3章的代码不需要 LLM，可直接运行
- 第1、4、5、6章需要配置 `.env` 中的 API Key
- 第9章的 AutoGen 示例默认连接本地 Ollama（`localhost:11434`）
