"""
HelloAgents — 轻量 Agent 框架

一个用于教学的轻量智能体框架，包含 LLM 调用中枢、消息系统、
配置管理和 Agent 抽象基类。

使用方式：
    from hello_agents import HelloAgentsLLM, SimpleAgent, Config, Message
"""

__version__ = "0.1.0"
